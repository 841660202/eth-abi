import { LitElement } from "lit";
import { TW } from "../util/TailwindMixin";

export const TwLitElement = TW(LitElement)