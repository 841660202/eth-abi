declare var style: string
export default style